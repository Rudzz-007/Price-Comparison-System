import React, { useState } from 'react';
import { Search, TrendingUp, TrendingDown, Activity, DollarSign, ShoppingCart, AlertCircle } from 'lucide-react';

function App() {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [prediction, setPrediction] = useState({});
  const [loading, setLoading] = useState(false);
  const [activePlatform, setActivePlatform] = useState('Zepto');
  const [error, setError] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query) return;
    setLoading(true);
    setError(null);

    try {
      // 1. Fetch live aggregated search results
      const searchRes = await fetch(`http://127.0.0.1:8000/api/v1/search?query=${query}`);
      if (!searchRes.ok) throw new Error("Failed to grab live platform data inputs.");
      const searchData = await searchRes.json();
      setSearchResults(searchData);

      // 2. Fetch market analytics trends
      const analyticsRes = await fetch(`http://127.0.0.1:8000/api/v1/analytics/trends?query=${query}`);
      const analyticsData = await analyticsRes.json();
      setAnalytics(analyticsData);

      // 3. Fetch default ML prediction for the active platform
      fetchPrediction(query, activePlatform);
    } catch (err) {
      console.error("Pipeline connectivity error:", err);
      setError("Unable to communicate with the FastAPI Backend. Verify Uvicorn is active on port 8000.");
    } finally {
      setLoading(false);
    }
  };

  const fetchPrediction = async (itemQuery, platformName) => {
    try {
      const predRes = await fetch(`http://127.0.0.1:8000/api/v1/predict/price?query=${itemQuery}&platform=${platformName}`);
      const predData = await predRes.json();
      setPrediction(predData);
    } catch (error) {
      console.error("Error fetching prediction:", error);
    }
  };

  const changePredictionPlatform = (platformName) => {
    setActivePlatform(platformName);
    if (query) {
      fetchPrediction(query, platformName);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans p-6">
      {/* Header Layout */}
      <header className="max-w-6xl mx-auto mb-8 flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center space-x-3">
          <ShoppingCart className="h-8 w-8 text-emerald-400" />
          <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
            Smart Grocery Aggregator
          </h1>
        </div>
        <span className="text-xs bg-gray-800 text-gray-400 px-3 py-1 rounded-full border border-gray-700">
          Frontend Engine Live
        </span>
      </header>

      {/* Main Framework View */}
      <main className="max-w-6xl mx-auto space-y-8">
        {/* Search Component Panel */}
        <section className="bg-gray-800 rounded-xl p-6 border border-gray-700 shadow-xl">
          <form onSubmit={handleSearch} className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3.5 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Query items across platforms (e.g., maggi, milk, bread)..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full bg-gray-950 border border-gray-700 rounded-lg pl-10 pr-4 py-3 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-700 text-gray-950 font-semibold px-6 py-3 rounded-lg transition-colors flex items-center space-x-2 cursor-pointer"
            >
              {loading ? 'Analyzing Datasets...' : 'Compare Prices'}
            </button>
          </form>
        </section>

        {/* Error Boundary Notification */}
        {error && (
          <div className="bg-rose-950/40 border border-rose-800/60 p-4 rounded-xl flex items-center gap-3 text-rose-300">
            <AlertCircle className="h-5 w-5 text-rose-400 shrink-0" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        {searchResults && analytics && !error && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Live Aggregated Results */}
            <div className="lg:col-span-2 space-y-6">
              <h2 className="text-xl font-semibold flex items-center gap-2 text-emerald-400">
                Live Price Comparisons (Sorted Lowest to Highest)
              </h2>
              <div className="space-y-4">
                {searchResults.results.map((item, idx) => (
                  <div key={idx} className="bg-gray-800 rounded-xl p-5 border border-gray-700 flex justify-between items-center hover:border-gray-600 transition-all shadow-md">
                    <div>
                      <span className="text-xs font-mono bg-gray-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900/50 mb-2 inline-block">
                        {item.platform}
                      </span>
                      <h3 className="text-lg font-medium text-gray-200">{item.title}</h3>
                      <p className="text-sm text-gray-400">Quantity Parameters: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-100">₹{item.price}</div>
                      <a
                        href={item.product_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-emerald-400 hover:underline mt-1 inline-block"
                      >
                        View Store Link →
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Column: Analytics & Data Science Trends */}
            <div className="space-y-6">
              <h2 className="text-xl font-semibold flex items-center gap-2 text-teal-400">
                Data Science Insights
              </h2>

              {/* Day 8 Enhancement: Visual Price Range Map */}
              <div className="bg-gray-800 rounded-xl p-5 border border-gray-700 space-y-4 shadow-md">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">30-Day Market Baseline</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-950 p-3 rounded-lg border border-gray-800">
                    <p className="text-xs text-gray-500">Avg Price</p>
                    <p className="text-lg font-bold text-gray-200">₹{analytics.market_summary.average_market_price}</p>
                  </div>
                  <div className="bg-gray-950 p-3 rounded-lg border border-gray-800">
                    <p className="text-xs text-gray-500">Historical Lowest</p>
                    <p className="text-lg font-bold text-emerald-400">₹{analytics.market_summary.lowest_historical_price}</p>
                  </div>
                </div>
                
                {/* Visual Tracker Bar */}
                <div className="space-y-1 pt-2 border-t border-gray-750">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Min: ₹{analytics.market_summary.lowest_historical_price}</span>
                    <span>Max: ₹{analytics.market_summary.highest_historical_price}</span>
                  </div>
                  <div className="w-full bg-gray-950 h-3 rounded-full overflow-hidden p-0.5 border border-gray-800">
                    <div className="bg-gradient-to-r from-emerald-500 via-yellow-500 to-rose-500 h-full rounded-full w-full"></div>
                  </div>
                </div>
              </div>

              {/* Predictive ML Window */}
              <div className="bg-gray-800 rounded-xl p-5 border border-gray-700 space-y-4 shadow-md">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                    <Activity className="h-4 w-4 text-purple-400" /> ML Forecast (7 Days)
                  </h3>
                  <select
                    value={activePlatform}
                    onChange={(e) => changePredictionPlatform(e.target.value)}
                    className="bg-gray-950 border border-gray-700 text-xs text-gray-300 rounded px-2 py-1 focus:outline-none cursor-pointer"
                  >
                    <option value="Zepto">Zepto</option>
                    <option value="Blinkit">Blinkit</option>
                    <option value="Swiggy Instamart">Swiggy Instamart</option>
                  </select>
                </div>

                {prediction.predicted_price !== undefined && (
                  <div className="bg-gray-950 p-4 rounded-lg border border-gray-800 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Current Price ({prediction.platform}):</span>
                      <span className="font-semibold text-gray-200">₹{prediction.current_market_price}</span>
                    </div>
                    <div className="flex justify-between items-center border-t border-gray-800 pt-2">
                      <span className="text-sm text-gray-400">Predicted Price:</span>
                      <span className="text-xl font-bold text-yellow-400">₹{prediction.predicted_price}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs font-medium mt-1 bg-gray-900 p-2 rounded border border-gray-800">
                      {prediction.market_trajectory?.includes('UPWARD') ? (
                        <TrendingUp className="h-4 w-4 text-rose-400" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-emerald-400" />
                      )}
                      <span className={prediction.market_trajectory?.includes('UPWARD') ? 'text-rose-400' : 'text-emerald-400'}>
                        Trajectory: {prediction.market_trajectory}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Platform Volatility Metric Tracker */}
              <div className="bg-gray-800 rounded-xl p-5 border border-gray-700 space-y-3 shadow-md">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Platform Volatility Index</h3>
                <div className="space-y-2">
                  {analytics.platform_breakdown.map((row, idx) => (
                    <div key={idx} className="flex justify-between items-center bg-gray-950 p-2.5 rounded border border-gray-800">
                      <span className="text-sm text-gray-300">{row.platform}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-mono text-gray-400">σ = {row.volatility_index}</span>
                        <div className="w-16 bg-gray-800 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className="bg-teal-400 h-full rounded-full" 
                            style={{ width: `${Math.min(row.volatility_index * 20, 100)}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;